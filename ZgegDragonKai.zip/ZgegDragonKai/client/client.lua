ESX = exports["es_extended"]:getSharedObject()


local PlayerData = {}

Citizen.CreateThread(function()

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer 
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
	
	Citizen.Wait(10)
end)

exports.qtarget:AddBoxZone("dragonkaiannounce", vector3(-171.6499, 302.6532, 98.51962), 2.2, 1, {
	name="dragonkaiannounce",
	heading=280.51727294921875,
	debugPoly=false,
	minZ=110.10,
	maxZ=110.60,
	}, {
		options = {
			{
				event = "DragonKai:bill",
				icon = "fas fa-cube",
				label = "Menu Facture",
				job = "dragonkai",
			},
		},
		distance = 2.5
})

RegisterNetEvent('DragonKai:bill')
AddEventHandler('DragonKai:bill', function()
      local input = lib.inputDialog('Facture DragonKai', {'Amount'})

           if input then
                local amount = tonumber(input[1])
			
				if amount == nil or amount < 0 then
					ESX.ShowNotification('Montant Invalide')
				else
					local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
				if closestPlayer == -1 or closestDistance > 4.0 then
					ESX.ShowNotification('Personne proche!')
				else
				TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(closestPlayer), 'society_dragonkai', 'Facture DragonKai', amount)
			end
		end
    end
end)


exports.qtarget:AddBoxZone("DragonKaiBoss", vector3(-177.1725, 302.1109, 100.899), 2.2, 1, {
	
	name="DragonKaiBoss",
	heading=148.0986785888672,
	debugPoly=false,
	minZ=110.3,
	maxZ=111.0,
	}, {
		options = {
			{
				event = "DragonKai:boss",
				icon = "fas fa-cube",
				label = "Menu Patron",
				job = "dragonkai",
			},
		},
		distance = 2.5
})

RegisterNetEvent('DragonKai:boss')
AddEventHandler('DragonKai:boss', function()
	TriggerEvent('esx_society:openBossMenu', 'DragonKai', function(data, menu)
		menu.close()
		end, { wash = false })
end)

exports.qtarget:AddBoxZone("DragonKaiDrinks", vector3(-173.4619, 302.4732, 98.52623), 2.4, 1, {
	name="DragonKaiDrinks",
	heading=94.8616714477539,
	debugPoly=false,
	minZ=109.80,
	maxZ=110.60,
	}, {
		options = {
			{
				event = "DragonKai:drinks",
				icon = "fas fa-cube",
				label = "Menu Boisson",
				job = "dragonkai",
			},
		},
		distance = 2.5
})



exports.qtarget:AddBoxZone("DragonKaiCook", vector3(-172.0738, 296.7482, 99.19701), 1.5, 1.5, {
	name="DragonKaiCook",
	heading=272.1419982910156,
	debugPoly=false,
	minZ = 110.01,
	maxZ = 114.01,
	}, {
		options = {
			{
				event = "DragonKai:cookmenu",
				icon = "fas fa-cube",
				label = "Menu Cuisson",
				job = "dragonkai",
			},
		},
		distance = 2.5
})

exports.qtarget:AddBoxZone("chawaaFridge", vector3(-172.4692, 290.4071, 99.197), 1.6, 1, {
	name="chawaaFridge",
	heading=181.7011871337891,
	debugPoly=false,
	minZ=109.90,
	maxZ=110.60,
	}, {
		options = {
			{
				event = "DragonKai:stash",
				icon = "fas fa-cube",
				label = "Menu Frigidaire",
				job = "dragonkai",
			},
		},
		distance = 2.5
})



exports.qtarget:AddBoxZone("DragonKaiBossStash", vector3(-175.6188, 308.5844, 101.0699), 1.6, 1, {
	name="DragonKaiBossStash",
	heading=5.44432020187377,
	debugPoly=false,
	minZ=109.90,
	maxZ=110.60,
	}, {
		options = {
			{
				event = "DragonKai:bossstash",
				icon = "fas fa-cube",
				label = "Coffre Patron",
				job = "dragonkai",
			},
		},
		distance = 1.5
})

RegisterNetEvent('DragonKai:bossstash')
AddEventHandler('DragonKai:bossstash', function()
	if ESX.PlayerData.job.name == 'dragonkai' and ESX.PlayerData.job.grade_name == 'boss' then
	OpenBossDragonKaiStash()
else
    ESX.ShowNotification('Tu a pas access a ce coffre!')
    end
end)






local reward = math.random(Config.Reward.Min, Config.Reward.Max)
local reward = math.random(Config.Reward.Min, Config.Reward.Max)
local times = 3

RegisterNetEvent('DragonKai:cookmenu')
AddEventHandler('DragonKai:cookmenu', function()
    lib.registerContext({
        id = 'DragonKai:cookmenu',
        title = 'Actions Cuisson',
        onExit = function()
        end,
        options = {
            {
                title = 'Nouille',
                description = 'Faire des nouilles',
                onSelect = function(args)
                    local item = 'nouille'  -- Spécifiez le nom de l'item
                    local times = 1  -- Vous pouvez définir le nombre de répétitions selon vos besoins
                    loadDict("anim@amb@business@coc@coc_unpack_cut@")
                    TaskPlayAnim(PlayerPedId(), "anim@amb@business@coc@coc_unpack_cut@", "fullcut_cycle_v6_cokecutter", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, times, 1 do
                        if lib.progressBar({
                            duration = 7500,  -- Temps pour la barre de progression
                            label = 'Préparation de ' .. item,  -- Utilisez le nom de l'item dans le label
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé des ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation des ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasksImmediately(PlayerPedId())
                end,
            },
            
            {
                title = 'Soba',
                description = 'Faire un Soba',
                onSelect = function(args)
                    local item = 'soba'
                    local times = 1
                    loadDict("anim@amb@business@coc@coc_unpack_cut@")
                    TaskPlayAnim(PlayerPedId(), "anim@amb@business@coc@coc_unpack_cut@", "fullcut_cycle_v6_cokecutter", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, times, 1 do
                        if lib.progressBar({
                            duration = 7500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé des ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation des ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasksImmediately(PlayerPedId())
                end,
            },
            
            {
                title = 'Burrito',
                description = 'Faire un Burrito',
                onSelect = function(args)
                    local item = 'burrito'
                    local times = 1
                    loadDict("anim@amb@business@coc@coc_unpack_cut@")
                    TaskPlayAnim(PlayerPedId(), "anim@amb@business@coc@coc_unpack_cut@", "fullcut_cycle_v6_cokecutter", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, times, 1 do
                        if lib.progressBar({
                            duration = 7500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé des ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation des ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasksImmediately(PlayerPedId())
                end,
            },
            
            {
                title = 'Donute Role',
                description = 'Faire un Donut',
                onSelect = function(args)
                    local item = 'dd_donut2'
                    local times = 1
                    loadDict("anim@amb@business@coc@coc_unpack_cut@")
                    TaskPlayAnim(PlayerPedId(), "anim@amb@business@coc@coc_unpack_cut@", "fullcut_cycle_v6_cokecutter", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, times, 1 do
                        if lib.progressBar({
                            duration = 7500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé des ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation des ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasksImmediately(PlayerPedId())
                end,
            },
            
            {
                title = 'Mufin Chocolat',
                description = 'Faire un Muffin',
                onSelect = function(args)
                    local item = 'dd_muffin'
                    local times = 1
                    loadDict("anim@amb@business@coc@coc_unpack_cut@")
                    TaskPlayAnim(PlayerPedId(), "anim@amb@business@coc@coc_unpack_cut@", "fullcut_cycle_v6_cokecutter", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, times, 1 do
                        if lib.progressBar({
                            duration = 7500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé des ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation des ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasksImmediately(PlayerPedId())
                end,
            },
            
            {
                title = 'Nachos',
                description = 'Faire des Nachos',
                onSelect = function(args)
                    local item = 'nachos'
                    local times = 1
                    loadDict("anim@amb@business@coc@coc_unpack_cut@")
                    TaskPlayAnim(PlayerPedId(), "anim@amb@business@coc@coc_unpack_cut@", "fullcut_cycle_v6_cokecutter", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, times, 1 do
                        if lib.progressBar({
                            duration = 7500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé des ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation des ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasksImmediately(PlayerPedId())
                end,
            },            
        },
    })
    lib.showContext('DragonKai:cookmenu')
end)



RegisterNetEvent('DragonKai:drinks')
AddEventHandler('DragonKai:drinks', function()
    lib.registerContext({
        id = 'DragonKai:drinks',
        title = 'Actions Boisson',
        onExit = function()
        end,
        options = {
            {
                title = 'Soju',
                description = 'Soju Alcool Fort',
                onSelect = function(args)
                    local item = 'soju'  -- Nom de l'item
                    loadDict("anim@mp_player_intupperspray_champagne")
                    TaskPlayAnim(PlayerPedId(), "anim@mp_player_intupperspray_champagne", "idle_a", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, 2, 1 do
                        if lib.progressBar({
                            duration = 3500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé un ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation du ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasks(PlayerPedId())
                    TriggerEvent('DragonKai:coke')
                end,
            },
            {
                title = 'Mogu Mogu',
                description = 'Faire un Mogu Mogu',
                onSelect = function(args)
                    local item = 'mogu'  -- Nom de l'item
                    loadDict("anim@mp_player_intupperspray_champagne")
                    TaskPlayAnim(PlayerPedId(), "anim@mp_player_intupperspray_champagne", "idle_a", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, 2, 1 do
                        if lib.progressBar({
                            duration = 3500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé un ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation du ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasks(PlayerPedId())
                    TriggerEvent('DragonKai:coke')
                end,
            },
            {
                title = 'Brisk',
                description = 'Faire un Brisk',
                onSelect = function(args)
                    local item = 'brisk_pink'  -- Nom de l'item
                    loadDict("anim@mp_player_intupperspray_champagne")
                    TaskPlayAnim(PlayerPedId(), "anim@mp_player_intupperspray_champagne", "idle_a", 1.0, -1.0, -1, 49, 0, false, false, false)
                    for i = 1, 2, 1 do
                        if lib.progressBar({
                            duration = 3500,
                            label = 'Préparation de ' .. item,
                            useWhileDead = false,
                            canCancel = true,
                            disable = {
                                car = true,
                            }
                        }) then
                            TriggerServerEvent('chawaa_DragonKai:add', 'item', 3, item)
                            lib.notify({
                                title = 'Succès',
                                description = 'Vous avez préparé un ' .. item .. ' avec succès.',
                                type = 'success'
                            })
                        else
                            lib.notify({
                                title = 'Annulé',
                                description = 'La préparation du ' .. item .. ' a été annulée.',
                                type = 'error'
                            })
                        end
                    end
                    ClearPedTasks(PlayerPedId())
                    TriggerEvent('DragonKai:coke')
                end,
            },
        },
    })
    lib.showContext('DragonKai:drinks')
end)


RegisterNetEvent('DragonKai:orderstash')
AddEventHandler('DragonKai:orderstash', function()
	OpenOrderDragonKai()
end)

function OpenOrderDragonKai()
	exports.ox_inventory:openInventory('stash', {id='DragonKaiOrderStash', owner= false})
end

RegisterNetEvent('DragonKai:stash')
AddEventHandler('DragonKai:stash', function()
	OpenDragonKaiStash()
end)	

function OpenBossDragonKaiStash()

	exports.ox_inventory:openInventory('stash', {id='DragonKaiBossStash', owner= false})
end

function OpenDragonKaiStash()
	exports.ox_inventory:openInventory('stash', {id='DragonKaiStash', owner= false, job = DragonKai})
end

loadDict = function(dict)
    while not HasAnimDictLoaded(dict) do Wait(0) RequestAnimDict(dict) end
end


