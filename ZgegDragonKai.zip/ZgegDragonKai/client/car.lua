local HasAlreadyEnteredMarker, LastZone = false, nil
local CurrentAction, CurrentActionMsg, CurrentActionData = nil, '', {}
local CurrentlyTowedVehicle, Blips, NPCOnJob, NPCTargetTowable, NPCTargetTowableZone = nil, {}, false, nil, nil
local NPCHasSpawnedTowable, NPCLastCancel, NPCHasBeenNextToTowable, NPCTargetDeleterZone = false, GetGameTimer() - 5 * 60000, false, false
local isDead, isBusy = false, false

Options = {}


-- veh start
exports.qtarget:AddBoxZone("DragonKai", vec3(-627.376831, 236.988892, 81.881462), 0.6, 1, {
	name="DragonKai",
	heading=0,
	--debugPoly=false,
	minZ=33.91,
	maxZ=34.90,
	}, {
		options = {
			{
				event = "chawaa_DragonKai:opengaragestar",
				icon = "fas fa-sign-in-alt",
				label = "DragonKai Garage",
				job = "dragonkai",
			},
		},
		distance = 3.5
})

for i = 1, #Config.cars do
    if i == 1 then
        Options[i] = { title = Config.cars[i].nom, args = Config.cars[i].modele, event = 'chawaa_DragonKai:delCar'}
    else
        Options[i] = { title = Config.cars[i].nom, args = Config.cars[i].modele, event = 'chawaa_DragonKai:spawnCar'}
    end
end
    lib.registerContext({
        id = 'opengaragestar',
        title = 'Garage',
        options = Options,
    })

RegisterNetEvent('chawaa_DragonKai:opengaragestar')
AddEventHandler('chawaa_DragonKai:opengaragestar',function()
	lib.showContext('opengaragestar')
end)

function createCar(car)
    local car = GetHashKey(car)

    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Wait(0)
    end

    local x, y, z = table.unpack(GetEntityCoords(PlayerPedId(), false))
    local vehicle = CreateVehicle(car, Config.DragonKai.SpawnVeh, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = Config.Plate..math.random(1,9)
    SetVehicleNumberPlateText(vehicle, plaque) 
    SetPedIntoVehicle(PlayerPedId(),vehicle,-1)
end

RegisterNetEvent('chawaa_DragonKai:spawnCar', function(data)
    createCar(data)
end)

RegisterNetEvent('chawaa_DragonKai:delCar')
AddEventHandler('chawaa_DragonKai:delCar',function()
    local veh = ESX.Game.GetClosestVehicle()
    DeleteEntity(veh)
end)

--- veh done 