lib.registerContext({
    id = 'menu_dragonkai',
    title = 'Intéraction Dragon Kai',
    menu = 'some_menu',
    onBack = function()
      print('Dragon Kai F6 !')
    end,
    options = {
      {
        title = 'Facture',
        icon = 'euro',
        description = 'Faire une Facture.',
        event = 'dragonkai:bill'
      },
      {
        title = 'Annonces',
        menu = 'annonces',
        description = 'Faire des annonce pour l\'entreprise !',
        icon = 'bullhorn'
      },
    }
  })



  lib.registerContext({
    id = 'annonces',
    title = 'Annonces',
    options = {
      {
      title = 'Entreprise Ouverte',
      icon = 'lock-open',
      description = 'Annoncer que votre entreprise est ouverte.',
      event = 'ouvert:dragon'
      },
  
      {
        title = 'Entreprise Fermer',
        icon = 'lock',
        description = 'Annoncer que votre entreprise est fermé.',
        event = 'fermer:dragon',
      },
      {
        title = 'Recrutement',
        icon = 'Fa-solid fa-user',
        description = 'Annoncer que votre entreprise recrute !.',
        event = 'recrutement:dragon',
      },
    }
  })


  RegisterCommand("menu_dragonkai", function()
    if ESX.PlayerData.job and ESX.PlayerData.job.name == 'dragonkai' and not ESX.PlayerData.dead then
        lib.showContext("menu_dragonkai")
    end
end)

RegisterKeyMapping("menu_dragonkai", "Ouvrir le Menu F6", "keyboard", "F6")



RegisterNetEvent('ouvert:dragon')
AddEventHandler('ouvert:dragon', function()
TriggerServerEvent('dragonkai:Open')
end)


RegisterNetEvent('fermer:dragon')
AddEventHandler('fermer:dragon', function()
TriggerServerEvent('dragonkai:Fermer')
end)

RegisterNetEvent('recrutement:dragon')
AddEventHandler('recrutement:dragon', function()
TriggerServerEvent('dragonkai:Recrutement')
end)




















RegisterNetEvent('dragonkai:bill')
AddEventHandler('dragonkai:bill', function()
      local input = lib.inputDialog('Facturé une personne', {'Amount'})

           if input then
                local amount = tonumber(input[1])
			
				if amount == nil or amount < 0 then
					ESX.ShowNotification('Montant Invalide')
				else
					local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
				if closestPlayer == -1 or closestDistance > 4.0 then
					ESX.ShowNotification('Personne proche !')
				else
				TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(closestPlayer), 'society_dragonkai', 'Facture Dragon Kai', amount)
			end
		end
    end
end)










local blips = {
  -- Exemple {title="CHAWAAAAAA", colour=, id=, x=, y=, z=},    -148.53860473633, 287.06311035156, 96.388206481934
 {title="~g~Entreprise~s~ | Dragon Kai ", colour=31, id=59, x = -148.53860473633, y = 287.06311035156, z = 96.388206481934}
}

Citizen.CreateThread(function()

  for _, info in pairs(blips) do
    info.blip = AddBlipForCoord(info.x, info.y, info.z)
    SetBlipSprite(info.blip, info.id)
    SetBlipDisplay(info.blip, 4)
    SetBlipScale(info.blip, 0.8)
    SetBlipColour(info.blip, info.colour)
    SetBlipAsShortRange(info.blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(info.title)
    EndTextCommandSetBlipName(info.blip)
  end
end)









