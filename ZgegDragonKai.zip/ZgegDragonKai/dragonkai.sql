
-- Listage des données de la table test2.addon_account : ~23 rows (environ)
INSERT INTO `addon_account` (`name`, `label`, `shared`) VALUES
	('society_dragonkai', 'Dragon Kai', 1);


-- Listage des données de la table test2.addon_account_data : ~24 rows (environ)
INSERT INTO `addon_account_data` (`id`, `account_name`, `money`, `owner`) VALUES
	(412121, 'society_dragonkai', 11026, NULL);



-- Listage des données de la table test2.addon_inventory : ~21 rows (environ)
INSERT INTO `addon_inventory` (`name`, `label`, `shared`) VALUES
	('society_dragonkai', 'Dragon Kai', 1);


-- Listage des données de la table test2.jobs : ~19 rows (environ)
INSERT INTO `jobs` (`name`, `label`) VALUES
	('dragonkai', 'Dragon Kai');



-- Listage des données de la table test2.job_grades : ~60 rows (environ)
INSERT INTO `job_grades` (`id`, `job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
	(98757, 'dragonkai', 1, 'crew', 'Stagiare Cuisinier', 40, '{}', '{}'),
	(98758, 'dragonkai', 2, 'crew', 'Cuisinier', 40, '{}', '{}'),
	(987579, 'dragonkai', 4, 'crew', 'Cuisinier Confirmée', 40, '{}', '{}'),
	(987577, 'dragonkai', 5, 'crew', 'Formateur Cuisine', 40, '{}', '{}'),
	(9875788, 'dragonkai', 6, 'boss', 'Responsable', 40, '{}', '{}'),
	(9875712, 'dragonkai', 7, 'boss', 'Co Patron', 40, '{}', '{}'),
	(9875714, 'dragonkai', 8, 'boss', 'Patron(e)', 40, '{}', '{}');
