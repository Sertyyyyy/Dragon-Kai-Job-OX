fx_version 'adamant'

game 'gta5'

developer 'chawaa'

lua54 'yes'

shared_scripts {
	'@ox_lib/init.lua',
	'@es_extended/framework/imports.lua'


}

client_scripts {
	'config.lua',
	'client/*.lua',
	'client/car.lua'


}

server_scripts {
	'server/*.lua',

}
