Config = {}
Config.EnableSocietyOwnedVehicles = false
Config.DrawDistance               = 10.0 -- How close you need to be in order for the markers to be drawn (in GTA units).
Config.MaxInService               = 50
Config.EnablePlayerManagement     = true -- Enable society managing.
Config.EnableSocietyOwnedVehicles = false


Config.Reward = { 
  Min = 20, 
  Max = 50 
}

Config.DragonTarget = true -- target 

Config.DragonTarget = {
    Facture = "Facture",

    IconFacture = "fa fa-credit-card",
}



Config.Zones = {

	VehicleSpawnPoint = {
		Pos   = vec4(-186.5101, 310.2907, 97.79967, 272.8322448730469),
		Size  = { x = 1.5, y = 1.5, z = 1.0 },
		Type  = -1
	}
}

Config.cars = {
    {nom = "Ranger véhicule", modele = ""},
    {nom = "DragonKai Camion", modele = "DragonKaismule1"},
}

Config.Plate = "DragonKai"

Config.DragonKai = {
    SpawnVeh = vec4(-182.72, 303.4687, 97.25963, 174.76551818847656),
}

