	['soju'] = {
		label = 'Soju',
		weight = 350,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_ecola_can`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
			notification = 'Tu vien de boire du Soju'
		}
	},

	['mogu'] = {
		label = 'Mogu',
		weight = 350,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_ecola_can`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
			notification = 'Tu vien de boire du Mogu'
		}
	},

	['nouille'] = {
		label = 'Nouille',
		weight = 220,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'chips',
			usetime = 2500,
			notification = 'Vous avez mangez des nouille'
		},
	},

	['soba'] = {
		label = 'Soba',
		weight = 220,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'chips',
			usetime = 2500,
			notification = 'Vous avez mangez des nouille'
		},
	},

	['burrito'] = {
		label = 'Burrito',
		weight = 220,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'chips',
			usetime = 2500,
			notification = 'Vous avez mangez un Burrito'
		},
	},
	
	['dd_donut2'] = {
		label = 'Donut Rose',
		weight = 220,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'chips',
			usetime = 2500,
			notification = 'Vous avez mangez un Donut'
		},
	},


	['dd_muffin'] = {
		label = 'Munfin Chocolat',
		weight = 220,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'chips',
			usetime = 2500,
			notification = 'Vous avez mangez un Donut'
		},
	},

	['nachos'] = {
		label = 'Nachos',
		weight = 220,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'chips',
			usetime = 2500,
			notification = 'Vous avez mangez un Nachos'
		},
	},