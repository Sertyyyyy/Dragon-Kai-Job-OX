RegisterServerEvent('dragonkai:Open')
AddEventHandler('dragonkai:Open', function()
    local _source  = source
    local xPlayer  = ESX.GetPlayerFromId(_source)
    local xPlayers = ESX.GetPlayers()
    for i = 1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], '', 'Entreprise', 'L\'entreprise ~b~Dragon Kai~s~ est maintenante ~g~ouverte~s~ !', 'CHAR_REDSIDE', 7)
    
    end
end)


RegisterServerEvent('dragonkai:Fermer')
AddEventHandler('dragonkai:Fermer', function()
    local _source  = source
    local xPlayer  = ESX.GetPlayerFromId(_source)
    local xPlayers = ESX.GetPlayers()
    for i = 1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], '', 'Entreprise', 'L\'entreprise ~b~Dragon Kai~s~ est maintenante ~r~Fermé~s~ !', 'CHAR_REDSIDE', 7)
    
    end
end)

RegisterServerEvent('dragonkai:Recrutement')
AddEventHandler('dragonkai:Recrutement', function()
    local _source  = source
    local xPlayer  = ESX.GetPlayerFromId(_source)
    local xPlayers = ESX.GetPlayers()
    for i = 1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], '', 'Entreprise', 'L\'entreprise ~b~Dragon Kai~s~ a ~g~ouvert~s~ c\'est Recrutement !', 'CHAR_REDSIDE', 7)
    
    end
end)