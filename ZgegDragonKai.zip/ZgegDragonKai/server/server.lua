ESX = exports["es_extended"]:getSharedObject()



TriggerEvent('esx_society:registerSociety', 'dragonkai', 'dragonkai', 'society_dragonkai', 'society_dragonkai', 'society_dragonkai', {type = 'public'})

--START OF BURGER--
local DragonKaistash = {
    id = 'DragonKaiStash',
    label = 'Coffre Employer',
    slots = 90,
    weight = 100000,
    owner = 'steam:'
}

local DragonKaiorderstash = {
    id = 'DragonKaiOrderStash',
    label = 'Menu Commandes',
    slots = 90,
    weight = 100000,
    owner = 'steam:'
}

local DragonKaiboss = {
    id = 'DragonKaiBossStash',
    label = 'Coffre Patron',
    slots = 90,
    weight = 100000,
    owner = 'steam:'
}

AddEventHandler('onServerResourceStart', function(resourceName)
    if resourceName == 'ox_inventory' or resourceName == GetCurrentResourceName() then
        Wait(0)
        exports.ox_inventory:RegisterStash(DragonKaistash.id, DragonKaistash.label, DragonKaistash.slots, DragonKaistash.weight, DragonKaistash.owner)
		exports.ox_inventory:RegisterStash(DragonKaiorderstash.id, DragonKaiorderstash.label, DragonKaiorderstash.slots, DragonKaiorderstash.weight, DragonKaiorderstash.owner)
        exports.ox_inventory:RegisterStash(DragonKaiboss.id, DragonKaiboss.label, DragonKaiboss.slots, DragonKaiboss.weight, DragonKaiboss.owner)
    end
end)


RegisterServerEvent('chawaa_DragonKai:add')
AddEventHandler('chawaa_DragonKai:add', function(type, amount, name)
	local xPlayer  = ESX.GetPlayerFromId(source)
	if type == 'money' then
		xPlayer.addMoney(amount)
		TriggerClientEvent('esx:showNotification', source, 'You recieved $'..amount, 'warn', 5000)
	elseif type == 'item' then
		xPlayer.addInventoryItem(name, amount)
	end
end)
RegisterServerEvent('chawaa_DragonKai:remove')
AddEventHandler('chawaa_DragonKai:remove', function(type, amount, name)
	local xPlayer  = ESX.GetPlayerFromId(source)

	if type == 'money' then
		xPlayer.removeMoney(amount)
	elseif type == 'item' then
		xPlayer.removeInventoryItem(name, amount)
	end
end)

